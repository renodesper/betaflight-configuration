-------------------------------------------------------------------------------
-- FM2M ToolBox - Telemetry script
-- version: 0.90 Beta
-- release date: 2024-01
-- author: Robert Janiszewski JimB40
-- http://fm2m.jimb40.com
-------------------------------------------------------------------------------
local FP = '/FM2M/'
local AP = 'TOOLBOX/'
return loadScript(FP..AP..'M','bx')('TLM',FP,AP,'bx')
