-------------------------------------------------------------------------------
-- FM2M ToolBox
-- version: 0.90
-- release date: 2024-01
-- author: Robert Janiszewski JimB40
-- http://fm2m.jimb40.com
-------------------------------------------------------------------------------
local toolName = "TNS|FM2M ToolBox 0.90|TNE"
local FP = '/FM2M/'
local AP = 'TOOLBOX/'
return { run=loadScript(FP..AP..'M','Tx')('SA',FP,AP,'Tx') }