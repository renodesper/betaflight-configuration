-------------------------------------------------------------------------------
-- FM2M ToolBox 0.90 Widget
-- release date: 2024-01
-- author: Robert Janiszewski
-- http://fm2m.JimB40.com
-------------------------------------------------------------------------------
local FP,AP,WNAME,SLM = '/FM2M/','TOOLBOX/','FM2M ToolBox','Tx'
return loadScript(FP..AP..'COLOR/WIDGET/loader',SLM)(FP,AP,WNAME,SLM)
